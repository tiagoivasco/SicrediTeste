package com.ivasco.sicrediteste.util

import java.text.SimpleDateFormat
import java.util.*

class Util {
    companion object {
        fun formateDate(date: String) : String? {
            val sdf = SimpleDateFormat("dd/MM/yyyy")
//            val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm")
            val netDate = Date(date.toLong())
            val retorno = sdf.format(netDate).toString()

            return sdf.format(netDate).toString()
        }
    }
}