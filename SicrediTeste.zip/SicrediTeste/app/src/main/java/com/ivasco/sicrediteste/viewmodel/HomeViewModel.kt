package com.ivasco.sicrediteste.viewmodel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.ivasco.sicrediteste.data.repository.SicrediRepository
import com.ivasco.sicrediteste.exceptions.CustomException
import com.ivasco.sicrediteste.model.CheckIn
import com.ivasco.sicrediteste.model.Events
import com.google.gson.Gson
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONObject
import retrofit2.HttpException
import java.lang.Error

class HomeViewModel : ViewModel() {
    private val apiRepository = SicrediRepository().makeRequest()
    val eventsResponse: MutableLiveData<ArrayList<Events>> = MutableLiveData()
    val eventPostResponse: MutableLiveData<Any> = MutableLiveData()

    fun getEvents() {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val events = apiRepository.getEvents()

                eventsResponse.postValue(events)
            } catch (exception: Exception) {
                Log.e("ERRO", "erro")
                exception.printStackTrace()
            }
        }
    }

    fun postEvent(checkInEvent: CheckIn) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val response = apiRepository.checkInEvent(checkInEvent)

                if (response.code() != 200 || response.code() != 204) {
                    eventPostResponse.postValue(false)
                } else {
                    eventPostResponse.postValue(true)
                }
            } catch (exception: Exception) {
                when (exception) {
                    is HttpException -> {
                        val jsonParsed = JSONObject(exception.response()?.errorBody()!!.toString())
                        val gson = Gson()
                        val cException =
                            gson.fromJson(jsonParsed.toString(), CustomException::class.java)

                        eventPostResponse.postValue(cException)
                    }
                }
            }
        }
    }
}